from django.contrib import admin
from .models import Barrack, Weapon, Soldier

admin.site.register(Barrack)
admin.site.register(Weapon)
admin.site.register(Soldier)
